<html>
<head>
  <link rel="stylesheet" type="text/css" href="mystile.css">  
</head>
<body>
<img src="Cabezera_Edit.jpg" />
<div class="container">
  <a href="index.html">Inicio</a>
    <div class="dropdown">
    <button class="dropbtn">Clases</button>
    <div class="dropdown-content">
      <a href="Asalto.html">Asalto</a>
      <a href="Medico.html">Médico</a>
      <a href="Apoyo.html">Apoyo</a>
			<a href="Explorador.html">Explorador</a>
			  </div>
  </div>
	<a href="Vehiculos.html">Vehiculos</a>
	<a href="Visualizar_Arma.php">Armas</a>
	<a href="Meter_Armas.php">Meter nueva arma</a>
</div>
<br>Bienvenido!</br>
<br>En esta página encontraras guías básicas de cómo funcionan las clases y los vehículos en Battlefield 1, así tendrás unas nociones básicas de cómo funciona el juego.</br>

<?php
if ( !isset($_POST['Arma']) ) {
?>
        
    <form action="<?php $_SERVER['PHP_SELF'] ?>"  method="post">
        Arma: <input type="text" name="Arma" size="8" /><br/>
        Daño: <input type="text" name="DMG" size="10" /><br/>
        Cargador: <input type="text" name="Cargador" size="10" /><br/>
        <input type="submit" name="env" value="ENVIAR"/>
    </form>	  
    
<?php    
}
else {
    $username = asier19;
    $password = Calvo1997;
    $servername = localhost;
    $database = Battlefield_1;
    $table = Armas_Asalto; 
try {
    //Conexión con una base de datos del servidor
    $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "Conexión con la base de datos '".$database."' del servidor '".$servername."' realizada.<br/>";
    
    echo "Arma: ".$_POST['Arma']."<br/>";
    echo "Daño: ".$_POST['DMG']."<br/>";
    echo "Cargador: ".$_POST['Cargador']."<br/>";    
    
    $sql = "INSERT INTO ".$table." (Arma, DMG, Cargador) VALUES ('".$_POST['Arma']."','".$_POST['DMG']."','".$_POST['Cargador']."')";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    echo "Arma añadida correctamente.<br/>";
    }
catch(PDOException $e) {
    if ($e->getCode() == "23000")
        echo "Imposible insertar el registro porque esa clave ya existe."."<br/>";
    else
        echo $e->getMessage();
}
}    
 //print "<br/><br/><br/>sql: ".$sql;
?>

</body>
</html>
